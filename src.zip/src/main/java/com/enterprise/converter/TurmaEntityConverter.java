package com.enterprise.converter;

import com.enterprise.model.entity.gestao.TurmaEntity;
import com.enterprise.service.gestao.TurmaService;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("turmaEntityConverter")
@RequestScoped
public class TurmaEntityConverter implements Converter<TurmaEntity> {

    @Inject
    private TurmaService turmaService;

    @Override
    public TurmaEntity getAsObject(FacesContext context, UIComponent component, String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            Long id = Long.valueOf(value);
            return turmaService.findById(id).orElse(null);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, TurmaEntity value) {
        if (value == null || value.getId() == null) {
            return "";
        }
        return String.valueOf(value.getId());
    }
}
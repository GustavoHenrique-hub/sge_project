package com.enterprise.dto.admin;

import com.enterprise.model.entity.admin.PerfilEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PerfilDTO {
    private Long id;
    private String perfil;
    private String descricao;

    public PerfilDTO(PerfilEntity acesso){
        this.id = acesso.getId();
        this.perfil = acesso.getPerfil();
        this.descricao = acesso.getDescricao();
    }
}